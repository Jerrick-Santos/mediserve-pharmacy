package com.mediserve.pharma.mediservepharma

class Order (transaction: Transaction, totalItemAmt: Int){

    var transaction = transaction
        private set

    var totalItemAmt = totalItemAmt
        private set

}