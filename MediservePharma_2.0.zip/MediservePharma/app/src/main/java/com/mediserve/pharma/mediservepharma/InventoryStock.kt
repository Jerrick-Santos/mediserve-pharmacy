package com.mediserve.pharma.mediservepharma

class InventoryStock (product: Product, qty: Int){

    var product = product
        private set

    var qty = qty
        private set
}