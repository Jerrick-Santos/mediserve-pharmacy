package com.mediserve.pharma.mediservepharma

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mediserve.pharma.mediservepharma.databinding.ActivityMainBinding
import com.mediserve.pharma.mediservepharma.databinding.ActivityProductCatalogueBinding

class ProductCatalogueActivity : ComponentActivity() {

    private lateinit var activityProductCatalogueBinding: ActivityProductCatalogueBinding
    private lateinit var productList : ArrayList<Product>
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.activityProductCatalogueBinding = ActivityProductCatalogueBinding.inflate(layoutInflater)
        setContentView(this.activityProductCatalogueBinding.root)

        this.productList = DataGenerator.generateProductList()

        this.recyclerView = this.activityProductCatalogueBinding.recyclerView

        this.recyclerView.adapter = ProductCatalogueAdapter(this.productList)
        this.recyclerView.layoutManager = LinearLayoutManager(this)


        //NAV BAR

        this.activityProductCatalogueBinding.navProdCat.setOnClickListener{
            intent = Intent(applicationContext, ProductCatalogueActivity::class.java)
            this.startActivity(intent);
        }

        this.activityProductCatalogueBinding.navProcessOrder.setOnClickListener{
            intent = Intent(applicationContext, ProcessOrderActivity::class.java)
            this.startActivity(intent);
        }

        this.activityProductCatalogueBinding.navInventory.setOnClickListener{
            intent = Intent(applicationContext, InventoryActivity::class.java)
            this.startActivity(intent);
        }

        this.activityProductCatalogueBinding.navTransactions.setOnClickListener{
            intent = Intent(applicationContext, ViewTransactions::class.java)
            this.startActivity(intent);
        }


    }
}